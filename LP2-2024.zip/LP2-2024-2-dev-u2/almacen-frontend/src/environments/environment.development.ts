export const environment = {
  HOST:'http://172.22.6.32:8080/SysAlmacen',
  RETRY: 2,
  TOKEN_NAME: 'access_token'
};
