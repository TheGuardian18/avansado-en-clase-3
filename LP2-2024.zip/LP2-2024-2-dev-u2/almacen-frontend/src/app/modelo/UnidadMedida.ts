export class UnidadMedida {
  idUnidad: number
  nombreMedida: string
}
