export class Acceso{
  idAcceso: number;
  nombre: string;
  url: string;
  icono: string;
 }
